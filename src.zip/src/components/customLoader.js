import Spinner from 'react-bootstrap/Spinner';
function CustomLoader() {
    return (
            <div className="custom-loader">
                <div className="fade modal-backdrop show"></div>
                <Spinner animation="border" role="status">
                <span className="visually-hidden">Loading...</span>
                </Spinner>
            </div>
    );
  }
  
  export default CustomLoader;