import React, {useState, useMemo,useEffect} from "react";
import Table from 'react-bootstrap/Table';
import Breadcrumb from 'react-bootstrap/Breadcrumb';
import { PieChart, pieArcLabelClasses} from '@mui/x-charts/PieChart';
//import talentData from "./talent.json";
import { useLocation } from "react-router-dom";
import axios from 'axios';
import { DataGrid, GridToolbar, gridFilteredSortedRowIdsSelector, selectedGridRowsSelector } from '@mui/x-data-grid';

import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-quartz.css';
import { AgGridReact } from 'ag-grid-react';

import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';
import FileSaver from 'file-saver';


function Summary() {

    

    const {state} = useLocation();
    console.log("mylocation+++++++",state);
    const [overview, setoverview] = useState(true);
    const [genai, setgenai] = useState(false);
    const [datasci, setdatasci] = useState(false);
    const [mlops, setMLOps] = useState(false);
    const [deeple, setdeeple] = useState(false);
    const [addskil, setaddskil] = useState(false);
    const [genaiData, setgenaiData] =useState();
    const [datascienceData, setdatascienceData] = useState();
    const [data, setData] = useState(state[4]);
    console.log("state 4 skillset", state[4]["skillset"]);
    
    const overviewClick=()=>{
        setoverview(true);
        setgenai(false);
        setdatasci(false);
        setaddskil(false);
        setMLOps(false);
        setdeeple(false);
    }
    const genaiClick = () =>{
     setoverview(false);
     setgenai(true);
     setdatasci(false);
     setaddskil(false);
     setMLOps(false);
     setdeeple(false);
     axios.get('http://localhost:3000/backend/genAI_sum', { withCredentials: true })
     .then(response=>{
         console.log("response genai tab",response.data);
         setRowData(response.data)
     })
     .catch((error) => {
        alert("Ther is some error processing the request. Please try again", error);
      });
    }
    const datasciClick = () =>{
     setoverview(false);
     setgenai(false);
     setdatasci(true);
     setaddskil(false);
     setMLOps(false);
     setdeeple(false);
     axios.get('http://localhost:3000/backend/dataScience_sum', { withCredentials: true })
     .then(response=>{
         console.log("response Data  Science tab",response.data);
         setRowDataScience(response.data);
     })
     .catch((error) => {
        alert("Ther is some error processing the request. Please try again", error);
      });
    }

   const mlopsClick = () =>{
    setoverview(false);
    setgenai(false);
    setdatasci(false);
    setaddskil(false);
    setMLOps(true);
    setdeeple(false);
    axios.get('http://localhost:3000/backend/mlops_sum', { withCredentials: true })
     .then(response=>{
         console.log("response Machine Learning tab",response.data);
         setRowMLOps(response.data);
     })
     .catch((error) => {
        alert("Ther is some error processing the request. Please try again", error);
      });
   }

   const deepleClick = () =>{
    setoverview(false);
    setgenai(false);
    setdatasci(false);
    setaddskil(false);
    setMLOps(false);
    setdeeple(true);
    axios.get('http://localhost:3000/backend/DeepLearning_sum', { withCredentials: true })
     .then(response=>{
         console.log("response genai tab",response.data);
         setRowDeeplearn(response.data);
     })
     .catch((error) => {
        alert("Ther is some error processing the request. Please try again", error);
      });
   }

    const Capitalize = (str) =>{
        return str.charAt(0).toUpperCase() + str.slice(1);
        }

//For Pie Chart
    let pieDataJson;
    if(data["skillset"] == "GenAI/DataScience" ) {
        // if (state[3]['Additional count']['Data Science Recommended'] > 0 && state[3]['Additional count']['GenAI Recommended'] > 0) {
        //     pieDataJson= [
        //         { label: 'Gen AI', value: state[1]['GenAI count']['Recommended']-state[3]['Additional count']['GenAI Recommended'] },
        //         { label: 'Gen AI + ' + Capitalize(data['additionalSkills']), value: state[3]['Additional count']['GenAI Recommended']},
        //         { label: 'DS', value: state[2]['Data Science count']['Recommended']-state[3]['Additional count']['Data Science Recommended'] },
        //         { label: 'DS + ' + Capitalize(data['additionalSkills']), value: state[3]['Additional count']['Data Science Recommended'] }
        //     ];  } else if (state[3]['Additional count']['GenAI Recommended'] > 0) {
        //     pieDataJson= [
        //         { label: 'Gen AI', value: state[1]['GenAI count']['Recommended']-state[3]['Additional count']['GenAI Recommended'] },
        //         { label: 'Gen AI + ' + Capitalize(data['additionalSkills']), value: state[3]['Additional count']['GenAI Recommended']},
        //         { label: 'DS', value: state[2]['Data Science count']['Recommended']-state[3]['Additional count']['Data Science Recommended'] }
        //     ];  } else if (state[3]['Additional count']['Data Science Recommended'] > 0) {
        //         pieDataJson= [
        //             { label: 'Gen AI', value: state[1]['GenAI count']['Recommended']-state[3]['Additional count']['GenAI Recommended'] },
        //             { label: 'DS', value: state[2]['Data Science count']['Recommended']-state[3]['Additional count']['Data Science Recommended'] },
        //             { label: 'DS + ' + Capitalize(data['additionalSkills']), value: state[3]['Additional count']['Data Science Recommended'] }
        //     ];  } else if (state[1]['GenAI count']['Recommended']>0 && state[2]['Data Science count']['Recommended']==0){
        //     pieDataJson = [
        //         { label: 'Gen AI', value: state[1]['GenAI count']['Recommended']  }
        //     ];
        // } else if (state[1]['GenAI count']['Recommended']==0 && state[2]['Data Science count']['Recommended']>0){
        //     pieDataJson = [
        //         { label: 'Data Science', value: state[2]['Data Science count']['Recommended'] }
        //     ];
        // } else {
        //     pieDataJson = [
        //         { label: 'Gen AI', value: state[1]['GenAI count']['Recommended']  },
        //         { label: 'Data Science', value: state[2]['Data Science count']['Recommended'] },
        //     ];
        // }
        if (state[3]['Additional count']['Data Science Recommended'] > 0 && state[3]['Additional count']['GenAI Recommended'] > 0 && state[3]['Additional count']['MLOps Recommended'] > 0) {
            pieDataJson = [
                { label: 'Gen AI', value: state[1]['GenAI count']['Recommended'] - state[3]['Additional count']['GenAI Recommended'] },
                { label: 'Gen AI + ' + Capitalize(data['additionalSkills']), value: state[3]['Additional count']['GenAI Recommended'] },
                { label: 'DS', value: state[2]['Data Science count']['Recommended'] - state[3]['Additional count']['Data Science Recommended'] },
                { label: 'DS + ' + Capitalize(data['additionalSkills']), value: state[3]['Additional count']['Data Science Recommended'] },
                { label: 'MLOps', value: state[7]['MLOps count']['Recommended'] - state[3]['Additional count']['MLOps Recommended'] },
                { label: 'MLOps + ' + Capitalize(data['additionalSkills']), value: state[3]['Additional count']['MLOps Recommended'] }
            ];
        } else if (state[3]['Additional count']['GenAI Recommended'] > 0) {
            pieDataJson = [
                { label: 'Gen AI', value: state[1]['GenAI count']['Recommended'] - state[3]['Additional count']['GenAI Recommended'] },
                { label: 'Gen AI + ' + Capitalize(data['additionalSkills']), value: state[3]['Additional count']['GenAI Recommended'] },
                { label: 'DS', value: state[2]['Data Science count']['Recommended'] - state[3]['Additional count']['Data Science Recommended'] },
                { label: 'MLOps', value: state[7]['MLOps count']['Recommended'] - state[3]['Additional count']['MLOps Recommended'] }
            ];
        } else if (state[3]['Additional count']['Data Science Recommended'] > 0) {
            pieDataJson = [
                { label: 'Gen AI', value: state[1]['GenAI count']['Recommended'] - state[3]['Additional count']['GenAI Recommended'] },
                { label: 'DS', value: state[2]['Data Science count']['Recommended'] - state[3]['Additional count']['Data Science Recommended'] },
                { label: 'DS + ' + Capitalize(data['additionalSkills']), value: state[3]['Additional count']['Data Science Recommended'] },
                { label: 'MLOps', value: state[7]['MLOps count']['Recommended'] - state[3]['Additional count']['MLOps Recommended'] }
            ];
        } else if (state[3]['Additional count']['MLOps Recommended'] > 0) {
            pieDataJson = [
                { label: 'Gen AI', value: state[1]['GenAI count']['Recommended'] - state[3]['Additional count']['GenAI Recommended'] },
                { label: 'DS', value: state[2]['Data Science count']['Recommended'] - state[3]['Additional count']['Data Science Recommended'] },
                { label: 'MLOps', value: state[7]['MLOps count']['Recommended'] - state[3]['Additional count']['MLOps Recommended'] },
                { label: 'MLOps + ' + Capitalize(data['additionalSkills']), value: state[3]['Additional count']['MLOps Recommended'] }
            ];
        } else if (state[1]['GenAI count']['Recommended'] > 0 && state[2]['Data Science count']['Recommended'] == 0 && state[7]['MLOps count']['Recommended'] == 0) {
            pieDataJson = [
                { label: 'Gen AI', value: state[1]['GenAI count']['Recommended'] }
            ];
        } else if (state[1]['GenAI count']['Recommended'] == 0 && state[2]['Data Science count']['Recommended'] > 0 && state[7]['MLOps count']['Recommended'] == 0) {
            pieDataJson = [
                { label: 'Data Science', value: state[2]['Data Science count']['Recommended'] }
            ];
        } else if (state[1]['GenAI count']['Recommended'] == 0 && state[2]['Data Science count']['Recommended'] == 0 && state[7]['MLOps count']['Recommended'] > 0) {
            pieDataJson = [
                { label: 'MLOps', value: state[7]['MLOps count']['Recommended'] }
            ];
        } else {
            pieDataJson = [
                { label: 'Gen AI', value: state[1]['GenAI count']['Recommended'] },
                { label: 'Data Science', value: state[2]['Data Science count']['Recommended'] },
                { label: 'MLOps', value: state[7]['MLOps count']['Recommended'] }
            ];
        }
        
    } else if (data["skillset"] == "Machine Learning") {
        if (state[3]['Additional count']['Machine learning Recommended'] > 0) {
            pieDataJson= [
                { label: 'ML', value: state[5]['Machine learning count']['Recommended']-state[3]['Additional count']['Machine learning Recommended'] },
                { label: 'ML + ' + Capitalize(data['additionalSkills']), value: state[3]['Additional count']['Machine learning Recommended']},
            ];  } else {
            pieDataJson = [
                { label: 'ML', value: state[5]['Machine learning count']['Recommended']}
            ];
        }
    } else {
        if (state[3]['Additional count']['Deep learning Recommended'] > 0) {
            pieDataJson= [
                { label: 'DL', value: state[6]['Deep learning count']['Recommended']-state[3]['Additional count']['Deep learning Recommended'] },
                { label: 'DL + ' + Capitalize(data['additionalSkills']), value: state[3]['Additional count']['Deep learning Recommended']},
            ];  } else {
            pieDataJson = [
                { label: 'DL', value: state[6]['Deep learning count']['Recommended']}
            ];
        }
    }

    const pieData = pieDataJson;
    console.log("pieData+=======",pieData);
    const TotalPercentage = () =>{ return ((state[0]['Resume Classification']['Recommended']/data.serial)*100).toFixed(0)};
    const pieChart = {
        startAngle: -90,
        endAngle: 90,
        paddingAngle: 0,
        innerRadius: 60,
        outerRadius: 115,
        data: pieData,
        arcLabel: (item) => {  
            return `${item.value}`;
        }
    }
    
    const downloadResume = (filename) =>{
        console.log("before response Path");
        axios.get('http://localhost:3000/backend/download?file_name='+filename,
        { responseType: 'blob' , withCredentials: true})
        .then((response)=>{
            console.log("response download", response);
            const href = window.URL.createObjectURL(response.data);
            const anchorElement = document.createElement('a');
            anchorElement.href = href;
            anchorElement.download = filename;
            document.body.appendChild(anchorElement);
            anchorElement.click();
            document.body.removeChild(anchorElement);
            window.URL.revokeObjectURL(href);
        })
        .catch((error) => {
            alert("Ther is some error processing the request. Please try again", error);
          });
      }

      const downloadQuestions = (name) =>{
        console.log("before response Path");
        axios.get('http://localhost:3000/backend/download_questions?name='+name,
        { responseType: 'blob' , withCredentials: true})
        .then((response)=>{
            console.log("response download", response);
            const href = window.URL.createObjectURL(response.data);
            const anchorElement = document.createElement('a');
            anchorElement.href = href;
            anchorElement.download = name+ '.docx';
            document.body.appendChild(anchorElement);
            anchorElement.click();
            document.body.removeChild(anchorElement);
            window.URL.revokeObjectURL(href);
        })
        .catch((error) => {
            alert("Ther is some error processing the request. Please try again", error);
          });
      }

      const genAITableExcel = () => {
        axios.get('http://localhost:3000/backend/genAI_sum', { withCredentials: true })
        .then((response) => {
            console.log("Gen AI Data", response);
            const worksheet = XLSX.utils.json_to_sheet(response.data);
    
            // Set the width of each column
            const columnWidths = response.data[0] ? Object.keys(response.data[0]).map(() => ({ wpx: 100 })) : [];
            worksheet['!cols'] = columnWidths;
    
            const workbook = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(workbook, worksheet, "Sheet1");
    
            // Buffer to store the generated Excel file
            const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
            const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8' });
    
            saveAs(blob, "Gen_AI_Data.xlsx");
        })
        .catch((error) => {
            alert("There is some error processing the request. Please try again", error);
        });
    }
    

      const DataSciTableExcel = () =>{
        axios.get('http://localhost:3000/backend/dataScience_sum', { withCredentials: true })
        .then((response)=>{
            console.log("Gen AI Data", response);
            const worksheet = XLSX.utils.json_to_sheet(response.data);
            const workbook = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(workbook, worksheet, "Sheet1");

            // Buffer to store the generated Excel file
            const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
            const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8' });

            saveAs(blob, "Data_Science.xlsx");
        })
        .catch((error) => {
            alert("Ther is some error processing the request. Please try again", error);
          });
      }
      const MLTableExcel = () =>{
        axios.get('http://localhost:3000/backend/mlops_sum', { withCredentials: true })
        .then((response)=>{
            console.log("Gen AI Data", response);
            const worksheet = XLSX.utils.json_to_sheet(response.data);
            const workbook = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(workbook, worksheet, "Sheet1");

            // Buffer to store the generated Excel file
            const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
            const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8' });

            saveAs(blob, "MLOps.xlsx");
        })
        .catch((error) => {
            alert("Ther is some error processing the request. Please try again", error);
          });
      }
      const DLTableExcel = () =>{
        axios.get('http://localhost:3000/backend/DeepLearning_sum', { withCredentials: true })
        .then((response)=>{
            console.log("Gen AI Data", response);
            const worksheet = XLSX.utils.json_to_sheet(response.data);
            const workbook = XLSX.utils.book_new();
            XLSX.utils.book_append_sheet(workbook, worksheet, "Sheet1");

            // Buffer to store the generated Excel file
            const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
            const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8' });

            saveAs(blob, "Deep_Learning.xlsx");
        })
        .catch((error) => {
            alert("Ther is some error processing the request. Please try again", error);
          });
      }

      const summaryExcel = () =>{
        axios.get('http://localhost:3000/backend/download_excel',
        { responseType: 'blob', withCredentials: true })
        .then((response)=>{
            console.log("response download", response);
            const href = window.URL.createObjectURL(response.data);
            const anchorElement = document.createElement('a');
            anchorElement.href = href;
            let currentDate = new Date()
            currentDate = currentDate.toLocaleDateString('en-US',{day: '2-digit', month: '2-digit',year: 'numeric'}).replace(/\//g,'-')
            anchorElement.download = "iReS_Resume_Summary_"+currentDate+".xlsx";
            document.body.appendChild(anchorElement);
            anchorElement.click();
            document.body.removeChild(anchorElement);
            window.URL.revokeObjectURL(href);
        })
        .catch((error) => {
            alert("There is some error processing the request. Please try again", error);
          });
      }
      const valueSum = (n1,n2) =>{
        return Number(n1)+Number(n2)
      }
    
    const CustomButtonComponent = ({ name, onClick }) => {
            return (
        <span onClick={onClick} className="down-link">
        <i className="bi bi-file-earmark-arrow-down-fill"></i> {name}
        </span>
            );
        };

    const pagination = true;
    const paginationPageSize = 10;
    const paginationPageSizeSelector = [10,20, 50, 100,500];
      console.log("genaiData+++++", genaiData)
      const [rowData, setRowData] = useState(genaiData);
      const [rowDataScience, setRowDataScience] = useState(genaiData);
      const [rowmlops, setRowMLOps] = useState(genaiData);
      const [rowDeeplearn, setRowDeeplearn] = useState(genaiData);
    
      const [colDefs, setColDefs] = useState([
        { field: 'rowIndex', width:60, headerName:"Sr.No" , cellClass: 'new-class', 
        valueFormatter: (params) => params.node.rowIndex + 1,
        },
        { field: 'Name', cellClass: 'new-class text-capitalize link' , wrapText: true, width:80,
        cellRendererParams:{
            colDef: {
            name:'Name',
            onClick: (params) => params.api.getColumnDef(params.colDef).cellRendererParams.onClick(params),
            }
        }},
        { field: 'Programming Language', headerName:"Languages", cellClass: 'new-class' , width:90},
        { field: 'GenAI', cellClass: 'new-class' ,wrapText: true, width:120},
        { field: 'Machine learning' , cellClass: 'new-class', wrapText: true, width:190},
        { field: 'Deep Learning', cellClass: 'new-class', width:189 },
        { field: 'MLOps', cellClass: 'new-class' , width:100},
        { field: 'Cloud', cellClass: 'new-class' , width:80},
        { field: 'GenAI Recommendation', cellClass: 'new-class' , width:130},
        { field: 'MLOps Recommendation', cellClass: 'new-class' , width:160},
        { field: 'Sample Question',headerName:"Questions", cellClass: 'new-class', cellRenderer: CustomButtonComponent, width:90, 
        cellRendererParams:{
            colDef: {
            name:'Name',
            onClick: (params) => params.api.getColumnDef(params.colDef).cellRendererParams.onClick(params),
            }
        }},
      ]);

      const [colDefsDs, setColDefsDS] = useState([
        { field: 'rowIndex', width:60, headerName:"Sr.No" , cellClass: 'new-class', 
        valueFormatter: (params) => params.node.rowIndex + 1,
        },
        { field: 'Name', cellClass: 'new-class text-capitalize link' , wrapText: true, width:80,
        cellRendererParams:{
            colDef: {
            name:'Name',
            onClick: (params) => params.api.getColumnDef(params.colDef).cellRendererParams.onClick(params),
            }
        }},
        { field: 'Programming Language', headerName:"Languages", cellClass: 'new-class' , width:90},
        { field: 'GenAI', cellClass: 'new-class' ,wrapText: true, width:120},
        { field: 'Machine learning' , cellClass: 'new-class', wrapText: true, width:190},
        { field: 'Deep Learning', cellClass: 'new-class', width:189 },
        { field: 'MLOps', cellClass: 'new-class' , width:100},
        { field: 'Cloud', cellClass: 'new-class' , width:80},
        { field: 'DS Recommendation', cellClass: 'new-class' , width:130},
        { field: 'MLOps Recommendation', cellClass: 'new-class' , width:160},
        { field: 'Sample Question',headerName:"Questions", cellClass: 'new-class', cellRenderer: CustomButtonComponent, width:90, 
        cellRendererParams:{
            colDef: {
            name:'Name',
            onClick: (params) => params.api.getColumnDef(params.colDef).cellRendererParams.onClick(params),
            }
        }},
      ]);

      const [colDefsMLOPs, setColDefsMLOPs] = useState([
        { field: 'rowIndex', width:60, headerName:"Sr.No" , cellClass: 'new-class', 
        valueFormatter: (params) => params.node.rowIndex + 1,
        },
        { field: 'Name', cellClass: 'new-class text-capitalize link' , wrapText: true, width:80,
        cellRendererParams:{
            colDef: {
            name:'Name',
            onClick: (params) => params.api.getColumnDef(params.colDef).cellRendererParams.onClick(params),
            }
        }},
        { field: 'Programming Language', headerName:"Languages", cellClass: 'new-class' , width:90},
        { field: 'GenAI', cellClass: 'new-class' ,wrapText: true, width:120},
        { field: 'Machine learning' , cellClass: 'new-class', wrapText: true, width:190},
        { field: 'Deep Learning', cellClass: 'new-class', width:189 },
        { field: 'MLOps', cellClass: 'new-class' , width:100},
        { field: 'Cloud', cellClass: 'new-class' , width:80},
        { field: 'MLOps Recommendation', cellClass: 'new-class' , width:160},
        { field: 'Sample Question',headerName:"Questions", cellClass: 'new-class', cellRenderer: CustomButtonComponent, width:90, 
        cellRendererParams:{
            colDef: {
            name:'Name',
            onClick: (params) => params.api.getColumnDef(params.colDef).cellRendererParams.onClick(params),
            }
        }},
      ]);
     

      const rowClass = 'my-row-class';

      const defaultColDef = useMemo(() => {
        return {
           filter: 'agTextColumnFilter',
        };
      }, []);
      
    return(
            <div className="container-full summary-container">
                <Breadcrumb className="breadcrum-wrapper">
                    <Breadcrumb.Item href="/">
                        Home
                    </Breadcrumb.Item>
                    <Breadcrumb.Item active>Summary</Breadcrumb.Item>
                </Breadcrumb>
                <div className="container-left-pane">
                <div className="left-pane">
                    <ul>
                        <li className={overview ?"overview-menu active": "overview-menu"} onClick={overviewClick}>Overview</li>
                        <li className={genai ?"genai-menu active": "genai-menu" + (data["skillset"] == "Machine Learning" || data["skillset"] == "Deep Learning" ? " disable-menu" : "")} onClick={genaiClick}>GenAI</li>
                        <li className={datasci ?"datasci-menu active": "datasci-menu" + (data["skillset"] == "Machine Learning" || data["skillset"] == "Deep Learning" ? " disable-menu" : "")} onClick={datasciClick}>Data Science</li>
                        <li className={mlops ?"machinelearn-menu active": "machinelearn-menu" + (data["skillset"] == "Machine Learning" || data["skillset"] == "Deep Learning" ? " disable-menu" : "")} onClick={mlopsClick}>MLOps</li>
                        <li className={deeple ?"deeplearn-menu active": "deeplearn-menu" +  (data["skillset"] == "GenAI/DataScience" || data["skillset"] == "Machine Learning" ? " disable-menu" : "")} onClick={deepleClick}>Deep Learning</li>
                        <li className={"additional-menu"} onClick={()=>summaryExcel()}><i className="bi bi-arrow-down-square-fill"></i>Summary Report</li>
                    </ul>
                </div>
                </div>
                <div className="container-right-summary">
                    <div className="right-block-content">
                      {overview &&
                      <div className="overview-block">
                       <h5 className="summary-title">Overview</h5>
                       <div className="summary-table">
                       <table>
                        <tbody>
                        <tr>
                            <th># Resume to Screen</th>
                            <th>Primary Skills</th>
                            <th>Additional Skillsets</th>
                            {/* <th>Path to the Folder</th> */}
                            </tr>
                            {
                                <tr>
                                <td>{data.serial}</td>
                                <td>{data.skillset}</td>
                                <td>{data.additionalSkills}</td>
                                {/* <td>{data.path}</td> */}
                                </tr>
                            }
                                
                        </tbody>
                        </table>
                      </div>
                      <div className="container-full">
                          <div className="resume-show">
                          <h5 className="summary-title">Resume Classification</h5>
                          <div className="resume-count">
                            <div className="count-block count-total">
                                <span>Total</span>
                                {
                                    <p>{data.serial}</p>
                                }
                            </div>
                            <div className="count-block gen-ai-num">
                                <span>Recommended</span>
                                <p>{state[0]['Resume Classification']['Recommended']}</p>
                            </div>
                            <div className="count-block data-sci-num">
                                <span>Not Recommended</span>
                                <p>{state[0]['Resume Classification']['Not Recommended']}</p>
                            </div>
                          </div>
                          <div className="recommended-content">
                          <h5 className="summary-title">Recommendation Classification</h5>
                          <div className="recommend-speedometer">
                            <PieChart
                                series={[
                                    pieChart
                                ]}
                                sx={{
                                    [`& .${pieArcLabelClasses.root}`]: {
                                      fill: 'white',
                                      fontSize: 14,
                                    },
                                  }}
                                margin={{ top: 110, bottom: 10, left: 100, right:100}}
                                height={150}
                                slotProps={{
                                legend: {
                                    direction: 'row',
                                    position: { vertical: 'bottom', horizontal: 'middle' },
                                    padding: 0,
                                    itemMarkWidth: 8,
                                    itemMarkHeight: 8,
                                    labelStyle: {
                                        fontSize: 10,
                                        color: '#000000'
                                      },
                                },
                                
                                }}
                            />
                          <p className="recomm-text">Overall {TotalPercentage()}% Recommended</p>
                          <p className="overlap-desc">(Each skillset has been considered as separate category. Hence, they might overlap.)</p>
                          </div>
                          </div>
                          </div>
                          <div className="skill-show">
                            {data["skillset"] == "GenAI/DataScience" &&
                            <div className="skill-show-list-wrapper">
                                    <h5 className="summary-title">Gen AI:</h5>
                                    <div className="summary-desc">Trending Skills in Gen AI Recommended resumes are: <strong>{state[1]['GenAI count']['Trend']}</strong></div>
                                    <div className="skill-details-wrapper">
                                        <div className="skill-details col-sm-5">
                                            <ul>
                                                <li>Recommended:  <strong>{state[1]['GenAI count']['Recommended']}</strong></li>
                                                
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                }
                                {data["skillset"] == "GenAI/DataScience" &&
                                <div className="skill-show-list-wrapper">
                                    <h5 className="summary-title">Data Science:</h5>
                                    <div className="summary-desc">Trending Skills in Data Science Recommended resumes are: <strong>{state[2]['Data Science count']['Trend']}</strong></div>
                                    <div className="skill-details-wrapper">
                                        <div className="skill-details col-sm-5">
                                            <ul>
                                                <li>Recommended:  <strong>{state[2]['Data Science count']['Recommended']}</strong></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                }
                                {data["skillset"] == "GenAI/DataScience" &&
                                <div className="skill-show-list-wrapper">
                                    <h5 className="summary-title">MLOps:</h5>
                                    <div className="summary-desc">Trending Skills in MLOps Recommended resumes are: <strong>{state[7]['MLOps count']['Trend']}</strong></div>
                                    <div className="skill-details-wrapper">
                                        <div className="skill-details col-sm-5">
                                            <ul>
                                                <li>Recommended:  <strong>{state[7]['MLOps count']['Recommended']}</strong></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                }
                                {data["skillset"] == "Machine Learning" &&
                                <div className="skill-show-list-wrapper">
                                    <h5 className="summary-title">Machine Learning:</h5>
                                    <div className="summary-desc">Trending Skills in Machine Learning Recommended resumes are: <strong>{state[5]['Machine learning count']['Trend']}</strong></div>
                                    <div className="skill-details-wrapper">
                                        <div className="skill-details col-sm-5">
                                            <ul>
                                                <li>Recommended:  <strong>{state[5]['Machine learning count']['Recommended']}</strong></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                }
                                {data["skillset"] == "Deep Learning" &&
                                <div className="skill-show-list-wrapper">
                                    <h5 className="summary-title">Deep Learning:</h5>
                                    <div className="summary-desc">Trending Skills in Deep Learning Recommended resumes are: <strong>{state[6]['Deep learning count']['Trend']}</strong></div>
                                    <div className="skill-details-wrapper">
                                        <div className="skill-details col-sm-5">
                                            <ul>
                                                <li>Recommended:  <strong>{state[6]['Deep learning count']['Recommended']}</strong></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                }
                            {data['additionalSkills'].length>0 &&
                            <div className="skill-show-list-wrapper">
                                <h5 className="summary-title">{data['additionalSkills']}:</h5>
                                <div className="summary-desc">Above skill has been incorporated as an additional parameter to enhance the effectivness of our results with the inclusion of 
                                {data["skillset"] == "GenAI/DataScience" && <span> Gen AI & Data Science Categories </span> }
                                {data["skillset"] == "Machine Learning" && <span> Machine Learning Category</span> }
                                {data["skillset"] == "Deep Learning" && <span> Deep Learning Category</span> }
                                </div>
                                <div className="skill-details-wrapper">
                                    <div className="skill-details col-sm-10">
                                        {/* <ul> */}
                                            {/* <li>Recommended: <strong>{state[3]['Additional count']['Recommended']}</strong></li>
                                            {data["skillset"] == "GenAI/DataScience" && <li>Gen AI Recommended: <strong>{state[3]['Additional count']['GenAI Recommended']}</strong></li>}
                                            {data["skillset"] == "GenAI/DataScience" &&<li>Data Science Recommended : <strong>{state[3]['Additional count']['Data Science Recommended']}</strong></li>}
                                            {data["skillset"] == "GenAI/DataScience" &&<li>MLOps Recommended : <strong>{state[3]['Additional count']['MLOps Recommended']}</strong></li>}
                                            {data["skillset"] == "Machine Learning" &&<li>Machine Learning Recommended : <strong>{state[3]['Additional count']['Machine learning Recommended']}</strong></li>}
                                            {data["skillset"] == "Deep Learning" &&<li>Deep Learning Recommended : <strong>{state[3]['Additional count']['Deep learning Recommended']}</strong></li>} */}
                                           
                                            <ul className="horizontal-list">
                                                <li>Recommended: <strong>{state[3]['Additional count']['Recommended']}</strong></li>
                                                {data["skillset"] === "GenAI/DataScience" && <li>Gen AI Recommended: <strong>{state[3]['Additional count']['GenAI Recommended']}</strong></li>}
                                                {data["skillset"] === "GenAI/DataScience" && <li>Data Science Recommended: <strong>{state[3]['Additional count']['Data Science Recommended']}</strong></li>}
                                                {data["skillset"] === "GenAI/DataScience" && <li>MLOps Recommended: <strong>{state[3]['Additional count']['MLOps Recommended']}</strong></li>}
                                            </ul>
                                        {/* </ul> */}
                                    </div>

                                </div>
                            </div>}
                            {data['additionalSkills'].length === 0 &&
                            <div className="skill-show-list-wrapper">
                            <h5 className="summary-title">No Additional Skills has been selected</h5>
                            </div>
                            }
                          </div>
                       </div>
                       </div> /* overview block close */
                      }
                      {genai &&
                      <div className="table-block genai-block overview-block">
                       <h5 className="summary-title">Gen AI</h5>
                       <div className="overall-summary-desc">
                            There are <strong>{state[1]['GenAI count']['Recommended']-state[3]['Additional count']['GenAI Recommended']}</strong> Gen AI Recommended Resumes. 
                            {(data['additionalSkills']) &&<span> Gen AI + {Capitalize(data['additionalSkills'])} Recommended Resumes: <strong>{state[3]['Additional count']['GenAI Recommended']}</strong>. </span>} 
                            {/* Gen AI + {Capitalize(data['additionalSkills'])} Recommended Resumes: <strong>{state[3]['Additional count']['GenAI Recommended']}</strong>.  */}
                            Trending Gen AI skills are <strong>{state[1]['GenAI count']['Trend']}</strong>.
                             Please find the below table for the same.
                        </div> 
                        <h5 className="summary-title">Summary
                        <span onClick={()=>genAITableExcel()} className="genai-table-data-download">Export Data</span>
                        </h5>
                        <div className="summary-table-wrapper">

                        <div className="ag-theme-quartz datatablenew scroll" style={{ width: '100%', height: 315 }}>
                            <AgGridReact 
                            rowData={rowData} 
                            columnDefs={colDefs} 
                            defaultColDef={defaultColDef}
                            rowSelection="multiple"
                            suppressRowClickSelection={true}
                            pagination={pagination}
                            paginationPageSize={paginationPageSize}
                            paginationPageSizeSelector={paginationPageSizeSelector}
                            rowClass={rowClass}
                            // unSortIcon={true} 
                            onCellClicked={(params) => {
                                if (params.colDef.field === 'Sample Question') {
                                    console.log("params+++++++++++++", params);
                                    downloadQuestions(params.data['File Name']);
                                } else if (params.colDef.field === 'Name'){
                                    downloadResume(params.data['File Name'])
                                }
                            }}
                            />
                            </div>
                        </div>
                      </div>
                      }
                      {datasci &&
                      <div className="table-block datascience-block overview-block">
                       <h5 className="summary-title">Data Science</h5>
                       <div className="overall-summary-desc">
                        There are <strong>{state[2]['Data Science count']['Recommended']-state[3]['Additional count']['Data Science Recommended']}</strong> Data Science Recommended Resumes. 
                        {(data['additionalSkills']) &&<span> DS + {Capitalize(data['additionalSkills'])} Recommended Resumes: <strong>{state[3]['Additional count']['Data Science Recommended']}</strong>. </span>}
                         Trending DS skills are <strong>{state[2]['Data Science count']['Trend']}</strong>.
                        Please find the below table for the same.
                        </div> 
                        <h5 className="summary-title">Summary
                        <span onClick={()=>DataSciTableExcel()} className="genai-table-data-download">Export Data</span>
                        </h5>
                        <div className="summary-table-wrapper scroll1">
                        <div className="ag-theme-quartz datatablenew scroll" style={{ width: '100%', height: 315 }}>
                        <AgGridReact 
                            rowData={rowDataScience} 
                            columnDefs={colDefsDs} 
                            defaultColDef={defaultColDef}
                            rowSelection="multiple"
                            suppressRowClickSelection={true}
                            pagination={pagination}
                            paginationPageSize={paginationPageSize}
                            paginationPageSizeSelector={paginationPageSizeSelector}
                            rowClass={rowClass}
                            onCellClicked={(params) => {
                                if (params.colDef.field === 'Sample Question') {
                                    console.log("params+++++++++++++", params);
                                    downloadQuestions(params.data['File Name']);
                                } else if (params.colDef.field === 'Name'){
                                    downloadResume(params.data['File Name'])
                                }
                            }}
                            />
                            </div>
                        </div>
                      </div>
                      }
                      {mlops &&
                      <div className="table-block datascience-block overview-block">
                      <h5 className="summary-title">MLOps</h5>
                      <div className="overall-summary-desc">
                            There are <strong>{state[7]['MLOps count']['Recommended']-state[3]['Additional count']['MLOps Recommended']}</strong> MLOps Recommended Resumes.  
                            {(data['additionalSkills']) &&<span> MLOps + {Capitalize(data['additionalSkills'])} Recommended Resumes: <strong>{state[3]['Additional count']['MLOps Recommended']}</strong>. </span>}                             
                             Trending MLOps skills are <strong>{state[7]['MLOps count']['Trend']}</strong>.
                            Please find the below table for the same.
                        </div>  
                       <h5 className="summary-title">Summary
                       <span onClick={()=>MLTableExcel()} className="genai-table-data-download">Export Data</span>
                       </h5>
                       <div className="summary-table-wrapper scroll1">
                       <div className="ag-theme-quartz datatablenew scroll" style={{ width: '100%', height: 315 }}>
                       <AgGridReact 
                           rowData={rowmlops} 
                           columnDefs={colDefsMLOPs} 
                           defaultColDef={defaultColDef}
                           rowSelection="multiple"
                           suppressRowClickSelection={true}
                           pagination={pagination}
                           paginationPageSize={paginationPageSize}
                           paginationPageSizeSelector={paginationPageSizeSelector}
                           rowClass={rowClass}
                           onCellClicked={(params) => {
                               if (params.colDef.field === 'Sample Question') {
                                   downloadQuestions(params.data['File Name']);
                               } else if (params.colDef.field === 'Name'){
                                   downloadResume(params.data['File Name'])
                               }
                           }}
                           />
                           </div>
                       </div>
                     </div>
                      }
                      {deeple &&
                      <div className="table-block datascience-block overview-block">
                      <h5 className="summary-title">Deep Learning</h5>
                      <div className="overall-summary-desc">
                            There are <strong>{state[6]['Deep learning count']['Recommended']-state[3]['Additional count']['Deep learning Recommended']}</strong> Deep Learning Recommended Resumes. 
                            {(data['additionalSkills']) &&<span> DL + {Capitalize(data['additionalSkills'])} Recommended Resumes: <strong>{state[3]['Additional count']['Deep learning Recommended']}</strong>. </span>}                             
                            Trending DL skills are <strong>{state[6]['Deep learning count']['Trend']}</strong>.
                            Please find the below table for the same.
                        </div>  
                       <h5 className="summary-title">Summary
                       <span onClick={()=>DLTableExcel()} className="genai-table-data-download">Export Data</span>
                       </h5>
                       <div className="summary-table-wrapper scroll1">
                       <div className="ag-theme-quartz datatablenew scroll" style={{ width: '100%', height: 315 }}>
                       <AgGridReact 
                           rowData={rowDeeplearn} 
                           columnDefs={colDefs} 
                           defaultColDef={defaultColDef}
                           rowSelection="multiple"
                           suppressRowClickSelection={true}
                           pagination={pagination}
                           paginationPageSize={paginationPageSize}
                           paginationPageSizeSelector={paginationPageSizeSelector}
                           rowClass={rowClass}
                           onCellClicked={(params) => {
                               if (params.colDef.field === 'Sample Question') {
                                   downloadQuestions(params.data['File Name']);
                               } else if (params.colDef.field === 'Name'){
                                   downloadResume(params.data['File Name'])
                               }
                           }}
                           />
                           </div>
                       </div>
                     </div>
                      }


                    </div>
                </div>
            </div>
    ) 
}
 
export default Summary;