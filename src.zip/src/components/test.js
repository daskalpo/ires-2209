import React from 'react';
import Marquee from 'react-marquee-slider';
import styled from 'styled-components';

const Container = styled.div`
  width: 74%;
  text-align: center;
  color: white;
  margin-top: 23px;
  background-color: black; /* Add a background color for better visibility */
`;

const App = () => {
  return (
    <Container>
      <Marquee velocity={25} onMouseOver={e => e.stop()} onMouseOut={e => e.start()}>
        Review your H2 goals and update notes regularly. In case you have not added goals, please add them immediately.
      </Marquee>
    </Container>
  );
};

export default App;
