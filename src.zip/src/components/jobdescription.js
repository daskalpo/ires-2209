import React, {useState, useMemo, useEffect} from "react";
// import Table from 'react-bootstrap/Table';
import Breadcrumb from 'react-bootstrap/Breadcrumb';
// import { PieChart, pieArcLabelClasses} from '@mui/x-charts/PieChart';
import { useLocation } from "react-router-dom";
import axios from 'axios';
// import { DataGrid, GridToolbar, gridFilteredSortedRowIdsSelector, selectedGridRowsSelector } from '@mui/x-data-grid';

import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-quartz.css';
import { AgGridReact } from 'ag-grid-react';

import * as XLSX from 'xlsx';
import { saveAs } from 'file-saver';

function Jobdescription(){  
    
    const {state} = useLocation();
    console.log("mylocation+++++++",state);
    // const [jobData, setJobData] = useState(Object.values(state));
    const [jobData, setJobData] = useState(Object.entries(state).map(([filename, data]) => ({ ...data, filename })));

    // useEffect(() => {
    //     axios.get('http://localhost:3002/backend/jd_bucket')
    //         .then(response=>{
    //             console.log("response jd tab",response.data);
    //             const data = Object.values(response.data); // convert object to array
    //             setjobData(data);
    //         })
    //         .catch((error) => {
    //             alert("There is some error processing the request. Please try again", error);
    //         });
    // }, []);

    
   

    const CustomButtonComponent = ({ name, onClick }) => {
        return (
    <span onClick={onClick} className="down-link">
    <i className="bi bi-file-earmark-arrow-down-fill"></i> {name}
    </span>
        );
    };
    const pagination = true;
    const paginationPageSize = 10;
    const paginationPageSizeSelector = [10,20, 50, 100,500];

    const [colDefs, setColDefs] = useState([
        { field: 'rowIndex', width:60, headerName:"Sr.No" , cellClass: 'new-class', 
        valueFormatter: (params) => params.node.rowIndex + 1,
        },
        { field: 'Name', cellClass: 'new-class text-capitalize link' , wrapText: true, width:120,
        cellRendererParams:{
            colDef: {
            name:'Name',
            onClick: (params) => params.api.getColumnDef(params.colDef).cellRendererParams.onClick(params),
            }
        }},
        { field: 'Recommended', headerName:"Recommendation", cellClass: 'new-class' , width:120},
        // { field: 'Reasoning' , cellClass: 'new-class', wrapText: true, width:250},
        { field: 'Gen AI Skills', cellClass: 'new-class', width:250 },
        { field: 'Percent', cellClass: 'new-class' , width:100},
        { field: 'Other Skills', cellClass: 'new-class' , width:250},
        { field: 'Experience', cellClass: 'new-class' , width:130},
        // { field: 'Sample Question',headerName:"Questions", cellClass: 'new-class', cellRenderer: CustomButtonComponent, width:90, 
        // cellRendererParams:{
        //     colDef: {
        //     name:'Name',
        //     onClick: (params) => params.api.getColumnDef(params.colDef).cellRendererParams.onClick(params),
        //     }
        // }},
      ]);

      const rowClass = 'my-row-class';

      const defaultColDef = useMemo(() => {
        return {
           filter: 'agTextColumnFilter',
        };
      }, []);


    const MLTableExcel = () =>{
        console.log("jobData", jobData);
        
        const orderedJobData = jobData.map(job => ({ 
            "Name": job.Name, 
            "Experience": job.Experience, 
            "Recommended": job.Recommended, 
            "Gen AI Skills": job["Gen AI Skills"], 
            "Relevant Skills": job["Relevant Skills"], 
            "Percent": job.Percent 
        }));
    
        const worksheet = XLSX.utils.json_to_sheet(orderedJobData);
        const workbook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(workbook, worksheet, "Sheet1");
    
        // Buffer to store the generated Excel file
        const excelBuffer = XLSX.write(workbook, { bookType: 'xlsx', type: 'array' });
        const blob = new Blob([excelBuffer], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;charset=UTF-8' });
    
        saveAs(blob, "Job_Description.xlsx");
    }

      const downloadQuestions = (name) =>{
        console.log("before response Path");
        axios.get('http://localhost:3000/backend/download_questions?name='+name,
        { responseType: 'blob', withCredentials: true })
        .then((response)=>{
            console.log("response download", response);
            const href = window.URL.createObjectURL(response.data);
            const anchorElement = document.createElement('a');
            anchorElement.href = href;
            anchorElement.download = name;
            document.body.appendChild(anchorElement);
            anchorElement.click();
            document.body.removeChild(anchorElement);
            window.URL.revokeObjectURL(href);
        })
        .catch((error) => {
            alert("Ther is some error processing the request. Please try again", error);
          });
      }

      const downloadResume = (filename) =>{
        console.log("before response Path");
        axios.get('http://localhost:3000/backend/download?file_name='+filename,
        { responseType: 'blob', withCredentials: true })
        .then((response)=>{
            console.log("response download", response);
            const href = window.URL.createObjectURL(response.data);
            const anchorElement = document.createElement('a');
            anchorElement.href = href;
            anchorElement.download = filename;
            document.body.appendChild(anchorElement);
            anchorElement.click();
            document.body.removeChild(anchorElement);
            window.URL.revokeObjectURL(href);
        })
        .catch((error) => {
            alert("Ther is some error processing the request. Please try again", error);
          });
      }

    return(
    <div className="container-full summary-container">
        <Breadcrumb className="breadcrum-wrapper">
                    <Breadcrumb.Item href="http://http://localhost:3000/">
                        Home
                    </Breadcrumb.Item>
                    <Breadcrumb.Item active>Job Description</Breadcrumb.Item>
        </Breadcrumb>

        <div className="container-left-pane">
        <div className="left-pane">
                    <ul>
                        <li className="overview-menu active">Job Description</li>
                         </ul>
                </div>
        </div>
        <div className="container-right-summary">
            <div className="right-block-content">

            <div className="table-block datascience-block overview-block">
                      {/* <h5 className="summary-title">Job Description</h5> */}
                      {/* <div className="overall-summary-desc">
                           
                        </div>   */}
                       <h5 className="summary-title">Job Description
                       <span onClick={()=>MLTableExcel()} className="genai-table-data-download">Export Data</span>
                       </h5>
                       <div className="summary-table-wrapper scroll1">
                       <div className="ag-theme-quartz datatablenew scroll" style={{ width: '100%', height: 315 }}>
                       <AgGridReact 
                           rowData={jobData} 
                           columnDefs={colDefs} 
                           defaultColDef={defaultColDef}
                           rowSelection="multiple"
                           suppressRowClickSelection={true}
                           pagination={pagination}
                           paginationPageSize={paginationPageSize}
                           paginationPageSizeSelector={paginationPageSizeSelector}
                           rowClass={rowClass}
                           onCellClicked={(params) => {
                               if (params.colDef.field === 'Sample Question') {
                                   downloadQuestions(params.data['Name']);
                               } else if (params.colDef.field === 'Name'){
                                    downloadResume(params.data.filename);
                               }
                           }}
                           />
                           </div>
                       </div>
                     </div>

        </div>
        </div>
    </div>
)
}
export default Jobdescription;
