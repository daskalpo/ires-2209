import 'ag-grid-community/styles/ag-grid.css';
import 'ag-grid-community/styles/ag-theme-quartz.css';
import { AgGridReact } from 'ag-grid-react';

// import { ClientSideRowModelModule } from "@ag-grid-community/client-side-row-model";
import React, {useState, useMemo} from "react";
import axios from 'axios';



const tableData = [
  {
    id:1, "Name of the candidate":"Chethan n",
    "Skills":"Python, TensorFlow, Yolo, Detectron, OpenCV, GPT API, SQL, NLTK, Spacy, FasterCNN, GoogLeNet, C++, ROS",
    "GenAI":"GPT API, Prompt engineering",
    "Data Science":"Data pipeline, Data handling, Sentiment analysis, Text classification, Object detection, Classification, Action recognition, State machine, Robotics, Automation, Embedded programming",
    "Cloud":"None",
    "Programming Languages":"Python, R",
    "View PDF":"C:\\Users\\2090025\\OneDrive - Cognizant\\Documents\\Resumes\\Chethan N.pdf",
    "Recommendation":"Yes. Recommended for Data Science profile.",
    "File Name":"Chethan N.pdf"},
  {id:2, "Name of the candidate":"Sooraj s","Skills":"Python, Docker, Flask, Amazon EC2, SciKit-learn, TensorFlow, Pytorch Numpy, Scipy, Pandas, PostgreSQL, OpenCV, LangChain, Pinecone, matplotlib","GenAI":"None","Data Science":"Natural Language Processing, Computer Vision, Machine Learning, Forecasting","Cloud":"AWS","Programming Languages":"Python","View PDF":"C:\\Users\\2090025\\OneDrive - Cognizant\\Documents\\Resumes\\Naukri_SOORAJS[6y_0m] (1) (1).docx","Recommendation":"Yes. Recommended for Data Science profile.",
  "File Name":"Naukri_SOORAJS[6y_0m] (1) (1).docx"},
  {id:3, "Name of the candidate":"Pooja d","Skills":"LSTM, Train test split, CNN, GRU, Matplotlib, RNN, Encoder, Decoder, Attention Based Encoder Decoder GRU, Logestic egression, SVM, KNN, MLP Classifier, Tokenization, stemming, Lemmatization, Word cloud, TF-IDF, Gensim, Sumy, Transformer","GenAI":"None","Data Science":"LSTM, CNN, RNN, Encoder, Decoder, Attention Based Encoder Decoder GRU, Logestic egression, SVM, KNN, MLP Classifier, Tokenization, stemming, Lemmatization, train test split, Word cloud, TF-IDF, Gensim, Sumy, Transformer","Cloud":"AWS","Programming Languages":"None","View PDF":"C:\\Users\\2090025\\OneDrive - Cognizant\\Documents\\Resumes\\Pooja D Ugale.pdf","Recommendation":"Yes. Recommended for Data Science profile.",
  "File Name":"Pooja D Ugale.pdf"},
  {id:4, "Name of the candidate":"Pooja d","Skills":"LSTM, Train test split, CNN, GRU, Matplotlib, RNN, Encoder, Decoder, Attention Based Encoder Decoder GRU, Logestic egression, SVM, KNN, MLP Classifier, Tokenization, stemming, Lemmatization, Word cloud, TF-IDF, Gensim, Sumy, Transformer","GenAI":"None","Data Science":"LSTM, CNN, RNN, Encoder, Decoder, Attention Based Encoder Decoder GRU, Logestic egression, SVM, KNN, MLP Classifier, Tokenization, stemming, Lemmatization, train test split, Word cloud, TF-IDF, Gensim, Sumy, Transformer","Cloud":"AWS","Programming Languages":"None","View PDF":"C:\\Users\\2090025\\OneDrive - Cognizant\\Documents\\Resumes\\Pooja D Ugale.pdf","Recommendation":"Yes. Recommended for Data Science profile.",
  "File Name":"Pooja D Ugale.pdf"},
  {id:5, "Name of the candidate":"Pooja d","Skills":"LSTM, Train test split, CNN, GRU, Matplotlib, RNN, Encoder, Decoder, Attention Based Encoder Decoder GRU, Logestic egression, SVM, KNN, MLP Classifier, Tokenization, stemming, Lemmatization, Word cloud, TF-IDF, Gensim, Sumy, Transformer","GenAI":"None","Data Science":"LSTM, CNN, RNN, Encoder, Decoder, Attention Based Encoder Decoder GRU, Logestic egression, SVM, KNN, MLP Classifier, Tokenization, stemming, Lemmatization, train test split, Word cloud, TF-IDF, Gensim, Sumy, Transformer","Cloud":"AWS","Programming Languages":"None","View PDF":"C:\\Users\\2090025\\OneDrive - Cognizant\\Documents\\Resumes\\Pooja D Ugale.pdf","Recommendation":"Yes. Recommended for Data Science profile.",
  "File Name":"Pooja D Ugale.pdf"},
  {id:6, "Name of the candidate":"Pooja d","Skills":"LSTM, Train test split, CNN, GRU, Matplotlib, RNN, Encoder, Decoder, Attention Based Encoder Decoder GRU, Logestic egression, SVM, KNN, MLP Classifier, Tokenization, stemming, Lemmatization, Word cloud, TF-IDF, Gensim, Sumy, Transformer","GenAI":"None","Data Science":"LSTM, CNN, RNN, Encoder, Decoder, Attention Based Encoder Decoder GRU, Logestic egression, SVM, KNN, MLP Classifier, Tokenization, stemming, Lemmatization, train test split, Word cloud, TF-IDF, Gensim, Sumy, Transformer","Cloud":"AWS","Programming Languages":"None","View PDF":"C:\\Users\\2090025\\OneDrive - Cognizant\\Documents\\Resumes\\Pooja D Ugale.pdf","Recommendation":"Yes. Recommended for Data Science profile.",
  "File Name":"Pooja D Ugale.pdf"}
]

const downloadFile = () =>{
  window.alert('clicked')
}

function Datatable(){
  const CustomButtonComponent = (props) => {
    return <button onClick={() => downloadResume('Pooja D Ugale.pdf')}>Download!</button>;
  };
  const [rowData, setRowData] = useState(tableData);

  const [colDefs, setColDefs] = useState([
    { field: 'id', width:80, headerName:"S.no" , cellClass: 'new-class'},
    { field: 'Name of the candidate', cellClass: 'new-class' , wrapText: true},
    { field: 'Skills' , cellClass: 'new-class', wrapText: true},
    { field: 'GenAI', cellClass: 'new-class' ,wrapText: true},
    { field: 'Data Science', cellClass: 'new-class' },
    { field: 'Cloud', cellClass: 'new-class' , width:80},
    { field: 'Programming Languages', cellClass: 'new-class' },
    { field: 'button',cellClass: 'new-class', cellRenderer: CustomButtonComponent},
  ]);
  const rowClass = 'my-row-class';



  const defaultColDef = useMemo(() => {
    return {
      filter: 'agTextColumnFilter',
      floatingFilter: true,
    };
  }, []); 

  const downloadResume = (filename) =>{
    console.log("before response Path");
    axios.get('http://54.237.10.33:3001/backend/download?file_name='+filename,
    { responseType: 'blob' })
    .then((response)=>{
        console.log("response download", response);
        const href = window.URL.createObjectURL(response.data);
        const anchorElement = document.createElement('a');
        anchorElement.href = href;
        anchorElement.download = filename;
        document.body.appendChild(anchorElement);
        anchorElement.click();
        document.body.removeChild(anchorElement);
        window.URL.revokeObjectURL(href);
    })
  }
  let gridApi;

    return(
      <div className="ag-theme-quartz datatablenew" style={{ width: '100%', height: 400 }}>
      <AgGridReact 
      rowData={rowData} 
      columnDefs={colDefs} 
      defaultColDef={defaultColDef}
      rowSelection="multiple"
      suppressRowClickSelection={true}
      pagination={true}
      rowClass={rowClass}
      />
      </div>
    )
}
export default Datatable;
