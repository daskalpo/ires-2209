import React, { useState, useRef, useEffect } from "react";
import axios from 'axios';
import Button from 'react-bootstrap/Button';
import Modal from 'react-bootstrap/Modal';
import CustomSpinner from "./customSpinner.js";
import buttonTextnew from "./button.json";
import Form from 'react-bootstrap/Form';
import InputGroup from 'react-bootstrap/InputGroup';
import { useNavigate } from "react-router-dom";
import io from 'socket.io-client';
import CustomLoader from "./customLoader.js";



function Resumescreening(){
  //const [selectfield, setValue1] = useState('');
  //const [additionalSkillset, setValue2] = useState('');
  const [files, setFiles] = useState([]);  
  const [jdfile, setJDFile] = useState([]);  
  const [jdfiles, setJDFiles] = useState([]);
  const [apikey,setAPIKey] = useState("");
  
  
  const [sessionStarted, setSessionStarted] = useState(false);

  const startSession = async () => {
  if (!sessionStarted) {
    try {
      const response = await axios.get('http://localhost:3000/backend/start', { withCredentials: true });
      console.log(response.data); // "Session started"
      setSessionStarted(true);
    } catch (error) {
      console.error('Error starting session:', error);
    }
  }
    };

    useEffect(() => {
      startSession();
    }, []);
  
  
  // const handleFileChange = (e) => {
  //   setFiles(e.target.files);
  //   setJDFile(e.target.jdfile);
  //   setJDFiles(e.target.jdfiles);
  // };

  const handleFileChange = (e) => {
    const newFiles = Array.from(e.target.files);
  
    if (e.target.name === 'files') {
      setFiles(prevFiles => [...prevFiles, ...newFiles]);
      console.log('619+++',files)
    } else if (e.target.name === 'jdfile') {
      setJDFile(prevJDFile => [...prevJDFile, ...newFiles]);
      console.log('797+++',jdfile)
    } else if (e.target.name === 'jdfiles') {
      setJDFiles(prevJDFiles => [...prevJDFiles, ...newFiles]);
    }
  };

  
  const handleSubmit2 = async (e) => {
  e.preventDefault();
  e.stopPropagation();
  const form = e.currentTarget;
  const formData = new FormData(); 
  if (form.checkValidity() === true) {
    setLoader({
        loader:true
       })
    settablefield({
      tablefield:true
     })
    //  setJdfield({
    //   jdfield:false
    //  })
     formData.append('selectfield', selectboxInputref.current.value);
     formData.append('additionalSkillset', additonalskillref.current.value);
     formData.append('apikey', apikey);
     // formData.append('difficultylevel',difficultylevel.current.value)
     for (let i = 0; i < files.length; i++) {
       formData.append('files', files[i]);
     }
     console.log('files===',files)
     try {
        //axios.post('http://54.237.10.33:3001/backend/upload', formData, {
         //headers: {
           //'Content-Type': 'multipart/form-data',
         //},
         axios.post('http://localhost:3000/backend/upload', formData, {
     withCredentials: true,
     headers: {
       'Content-Type': 'multipart/form-data',
     },
       }).then(function (response) {
        console.log(response);
        if(response.status == '200'){
          let updateserial = response.data["numberofresumes"];
          setData([{"serial":updateserial,"skillset":selectboxInputref.current.value,"additionalSkills":additonalskillref.current.value}]);
          setLoader(false)
          setModalShow(true)
          // initialSummaryAPI()
        } else {
          alert('Unable to fetch initial summary')
        };
       });
     } catch (error) {
       console.error('Error uploading files:', error);
     }
    } else {
      alert("Not Validated")
    }    
  }

    
  


  const selectboxInputref = useRef();
    const additonalskillref = useRef();
    const pathref = useRef();
    // const difficultylevel = useRef();
    const navigate = useNavigate();
      const selectoptions = [
        {value: 'GenAI/DataScience'}
        // {value: 'Machine Learning'},
        // {value: 'Deep Learning'}
    ];
    const selectadditionaloptions = [
      {value: 'Please select an additional skill'},
      {value: 'Alteryx'},
      {value: 'Dataiku'},
      {value: 'Power BI'},
      {value: 'Others'}
  ];
    // const selectdifficultylevel = [
  //   // {value: 'Easy'},
  //   {value: 'Normal'},
  //   {value: 'Strict'},
  // ]

    const [optionselect,setoptionselect] = useState();
    const [tablefield, settablefield] = useState(false);
    const [jdfield, setJdfield] = useState(false);
    const [jdquestions, setJdQuestions] = useState(false);
    const [informationField, setInformationField] = useState(false);
    const [show, setModalShow] = useState(false);
    const [data, setData] = useState();
    const handleModalClose = () => {setModalShow(false);setSpinner(false);setLoader(false)};
    const [chartfield, setchartfield] = useState(false);
    const [InfoModalshow, setInfoModalShow] = useState(false);
    
    const [spinner, setSpinner] = useState(false);
    const [buttonText, setButtonText] = useState(buttonTextnew);
    const [validated, setValidated] = useState(false);
    const [formExpand, setFormExpand] = useState(false);
    const [skillbase, setSkillbase] = useState(true);
    const [jdbase, setJdbase] = useState(false);
    const [showiresform,setshowiresform] = useState(true);
    const [showjdform,setshowjdform] = useState(false); 
    const [progress, setProgress] = useState(0);
    const socket = io('http://localhost:3000');
    const [loader, setLoader] = useState(false);   
    
    useEffect(() => {
      socket.on('progress', (data) => {
        setProgress(data.progress);
      });
   
      return () => {
        socket.off('progress');
      };
    }, [socket]);
    
    const handleModalShow = (e) => {
      
      const form = e.currentTarget;
      e.preventDefault();
      e.stopPropagation();
      if (form.checkValidity() === true) {
        setSpinner({
          spinner:true
         })
        settablefield({
          tablefield:true
         })
         axios.post('http://localhost:3000/backend/input', {
          selectfield:selectboxInputref.current.value,
          additionalSkillset: additonalskillref.current.value,
          resumepath: pathref.current.value
        })
        .then(function (response) {
          console.log(response);
          if(response.status == '200'){
            setSpinner(true)
            initialSummaryAPI()
          } else {
            alert('Unable to fetch initial summary')
          }
        })
        .catch(function (error) {
          alert('Unable to fetch initial summary')
        })
      }
      setValidated(true);
     
      
    }
    
    //Get Initial Summary on Modal Open
    const initialSummaryAPI = () => {
        axios.get('http://localhost:3000/backend/user_summary')
        .then(response => {
          console.log("0000++++",response.data);
          let updateserial = response.data["# Resumes to Screen"][0];
          setData([{"serial":updateserial,"skillset":selectboxInputref.current.value,"additionalSkills":additonalskillref.current.value,"path":pathref.current.value}]);
          setSpinner(false)
          setModalShow(true);
        })
      }

    //Get Initial Summary on Modal Open
    const processResumes= () => {
      setSpinner(true)
      axios.get('http://localhost:3000/backend/new_res_summary', { withCredentials: true })
      .then(response => {
        console.log("response res summary",response);
        if(Number(response.status) === 200){
        console.log('11111++++',response.data);
        setSpinner(false)
        
        navigate('/summary', {state:response.data});
        } else {
          setSpinner(false)
          alert('Unable to Process Resumes')
        }
      })
      .catch(function (error) {
        setSpinner(false)
        alert('Unable to Process Resumes')
      })
    }

    // const processJd= () => {
    //   setSpinner(true)
    //   axios.get('http://localhost:3002/backend/jd_bucket')
    //   .then(response => {
    //     console.log("response jd questions",response);
    //     if(Number(response.status) === 200){
    //     console.log('jd====',response.data);
    //     setJdQuestions(response.data)
    //     // let questionserial = response.data
    //     // setData([{"questionserial":questionserial}]);
    //     setSpinner(false)
        
    //     // navigate('/jobdescription', {state:response.data});
    //     } else {
    //       setSpinner(false)
    //       alert('Unable to Process Resumes')
    //     }
    //   })
    //   .catch(function (error) {
    //     setSpinner(false)
    //     alert('Unable to Process Resumes')
    //   })
    // }

    
      const handleSubmit = (e) =>{
        e.preventDefault();
        setchartfield({
          chartfield:true
        })
        console.log("chartfield after submit",chartfield)
        setModalShow(false);
        //Resume Summary
        processResumes()        
      }

      

      const selectAdditionalskills = (e) =>{
        
        
        if(e.target.value === "Others"){
          setFormExpand(true);
          additonalskillref.current.disabled = false;
          additonalskillref.current.value = "";
        } else if(e.target.value === "Please select an additional skill"){
          setFormExpand(false);
          additonalskillref.current.disabled = false;
          additonalskillref.current.value = "";
        }
        else{
          setFormExpand(false);
          additonalskillref.current.disabled = true;
          additonalskillref.current.value = e.target.value;
        }
      }
      const infoModelOpen = () =>{
        console.log("Open")
        setInformationField(true);
        setInfoModalShow(true)
      }
      const infoModelClose = () =>{
        setInformationField(false);
        setInfoModalShow(false)
        console.log("Close")
      }

      const skillbaseSelection = () =>{
        setSkillbase(true);
        setshowiresform(true);
        setshowjdform(false);
        setJdbase(false);
      }

      const jdbaseSelection = () =>{
        setJdbase(true);
        setshowjdform(true);
        setshowiresform(false);
        setSkillbase(false);
      }

      const handleSubmit3 = (e) =>{
        e.preventDefault();
        setSpinner(true)
        setJdfield({
          jdfield:true
        })
        setModalShow(false)
      axios.get('http://localhost:3000/backend/jd_bucket', { withCredentials: true })
      .then(response => {
        console.log("response jd questions",response);
        if(Number(response.status) === 200){
        console.log('jd====',response.data);
        setJdQuestions(response.data)
        // let questionserial = response.data
        // setData([{"questionserial":questionserial}]);
        setSpinner(false)        
        
        navigate('/jobdescription', {state:response.data});
        console.log('state',response.data)
        } else {
          setSpinner(false)
          alert('Unable to Process Resumes')
        }
      })
      .catch(function (error) {
        setSpinner(false)
        alert('Unable to Process Resumes')
      })
    }

      const jdSubmit = async (e) =>{
        e.preventDefault();
        e.stopPropagation();
        const form = e.currentTarget;
        const formData = new FormData();
        formData.append('apikey', apikey);
        if (form.checkValidity() === true) {
          setSpinner({
            spinner:true
           })
          setJdfield({
            jdfield:true
           })
           if (jdfile && jdfile.length > 0) {
            for (let i = 0; i < jdfile.length; i++) {
              formData.append('jdfile', jdfile[i]);
            }
          }
          console.log('jdfile===',jdfile)
          
          if (jdfiles && jdfiles.length > 0) {
            for (let i = 0; i < jdfiles.length; i++) {
              formData.append('jd_files', jdfiles[i]);
            }
          }
          console.log('jdfiles===',jdfiles)
           try {
            axios.post('http://localhost:3000/backend/JD_upload_new', formData, {
         withCredentials: true,
         headers: {
           'Content-Type': 'multipart/form-data',
         },
       }).then(function (response) {
              console.log(response);
              if(response.status === 200){
                let updateserial = response.data["numberofresumes"]
                let updateserialJD= response.data["numberofJD"];
                let questionserial = response.data["questions"];
                let questionsArr = [];
                let serialNumber = 1;
                for (let key in questionserial) {
                  let filename = key.split('/').pop();
                  let questionsWithSerial = questionserial[key].map((question, index) => `${serialNumber++}. ${question}`);
                  questionsArr.push({filename: filename, questions: questionsWithSerial});
                }
                let questionsStr = questionsArr.join('\n');
                setData([{"serial":updateserial,"jdserial":updateserialJD,"questions":questionsArr}]);
                setSpinner(false)
                setModalShow(true)
                // initialSummaryAPI()
                // processJd()
              } else {
                alert('Unable to fetch initial summary')
              };
             });
           } catch (error) {
             console.error('Error uploading files:', error);
           }
          } else {
            alert("Not Validated")
          }  
        // navigate('/jobdescription')
      }
    return(
        <div>
          {/* Spinner  Starts*/}
          {spinner && <CustomSpinner progress={progress}/>}
          {loader && <CustomLoader/>}
             {/* Spinner  Ends*/}
            <div className="container-full">
            <div className="full-width-block top-container">
            <div className="left-content-block">
            <div className="left-image">
             <img src="https://cognizant.scene7.com/is/image/cognizant/nsdl-blockchain-platform-protects-investors-hero" alt=""/>
            </div>
            </div>
            <div className="middle-content-block">
            <div className="fullwidthClass form-contant">
                <h5>Please fill out the below form for Efficient & Accurate Hiring Process <i className="bi bi-info-circle-fill" onClick={infoModelOpen}></i></h5>
            <div className="base-selection-button-block">
            <ul>
              <li className={skillbase ? "skill-selection active" : "skill-selection"} onClick={skillbaseSelection}>Skill Based</li>
              <li className={jdbase ? "jd-selection active" : "jd-selection"} onClick={jdbaseSelection}>JD Based</li>
            </ul>
            </div>
            {/* <!--base-selection-button-block--> */}
            {showiresform &&
            <Form noValidate validated={validated} onSubmit={handleSubmit2} className={formExpand ?"ires-form expand-only": "ires-form"}>
            <div className="full-block">
              <div className="reg-input-block-half">
              <label>Primary Skills</label>
              <select ref={selectboxInputref} className="form-control" placeholder='Please select a skillset'>
                  {selectoptions.map(item => {
                    return (<option key={item.value} value={item.value}>{item.value}</option>);
                  })}
              </select>
              </div>
              <div className="reg-input-block-half">
              <label>Additional Skills (Optional)</label>
              <select onChange={(e)=>selectAdditionalskills(e)} className="form-control" placeholder='Please select an additionl skill'>
                  {selectadditionaloptions.map(item => {
                    return (<option key={item.value} value={item.value}>{item.value}</option>);
                  })}
              </select>
              </div>
              </div>
            
              <div className="full-block addition-input">
              <div className="reg-input-block-full">
              <label>Additional Skills (Enabled if Others are selected)</label>
              <input ref={additonalskillref} type="text" className="form-control" placeholder="Please enter an additional skill"/>
              </div>
              </div>
              
              <div className="full-block">
              <div className="reg-input-block-full">
              <div className="reg-input-block-full-skill-based">
                <div className="left-side-block-for-resume-folder">
                    <Form.Group controlId="validationCustomPath">
                        <Form.Label>Enter the resume folder</Form.Label>
                        <InputGroup hasValidation>                          
                          <Form.Control
                            type="file"
                            webkitdirectory="true"
                            placeholder="Please enter the folder path"
                            aria-describedby="inputPath"
                            name="files"
                            required
                            className="form-control"
                            // ref={pathref}
                            //value={folderpathnew}
                            onChange={handleFileChange}
                            />
                          <Form.Control.Feedback type="invalid">
                            Please Enter a Path
                          </Form.Control.Feedback>
                        </InputGroup>
                      </Form.Group>
                      </div>
                      <div className="right-side-block-for-api-key">
                      <Form.Label style={{marginTop:'2px'}}>Enter the Gemini API key <a className="text-decoration" href="
                          https://aistudio.google.com/app/apikey"
                          >(Click to get your API key)</a></Form.Label>
                        <input className="form-control input-text-height"
                            required
                            placeholder="Gemini API key"
                            value={apikey}
                            onChange={e => setAPIKey(e.target.value)}
                          />
                          </div>
                          </div>
                      {/* <div className="api-key-threshold-overall-section" >
                                  <div className='api-key-section'>
                                    <Form.Label>Enter the Gemini API key <a className="text-decoration" href="
  https://aistudio.google.com/app/apikey"
  >(Get your API key)</a></Form.Label>
                                      <input className="form-control input-text-height"
                                          required
                                          placeholder="Gemini API key"
                                          value={apikey}
                                          onChange={e => setAPIKey(e.target.value)}
                                      />
                                    </div>
                                    <div className="reg-input-block-half" >
                                      <label>Strictness Level</label>
                                      <select  ref={difficultylevel} className="form-control" placeholder='Please select difficulty level'>
                                          {selectdifficultylevel.map(item => {
                                            return (<option key={item.value} value={item.value}>{item.value}</option>);
                                          })}
                                      </select>
                                      </div>
                                  </div> */}
              </div>   
              </div>
              <div className="submit-block"><button className="submit-button btn btn-primary">Submit</button>
              </div> 
              </Form>
              }
              
              {
              showjdform &&
              <Form className="jd-form">

              <div className="full-block addition-input">
              <div className="reg-input-block-half">
              {/*<label>Job Description</label>
              <textarea  className="form-control input-height" placeholder="Please enter an Job Description"/>*/}
              </div>
              <div className="reg-input-block-half-jd">
              <label className= "form-label" style={{marginBottom:'4px'}}>Required Skills and Qualification</label>
              <textarea  className="form-control input-height" placeholder="Please enter an Skills and Qualification (Separated by ';' )"/>
              </div>
              </div>
              {/*<div className="full-block addition-input">
              <div className="reg-input-block-full">
              <label>Upload Resumes</label>
              <input type="file" className="form-control" placeholder="Please enter the folder path" multiple/>*/}
              <div className="full-block">
              <div className="reg-input-block-full">
                    <Form.Group controlId="validationCustomPath">                        
                        <InputGroup hasValidation>
                            <div className="jd-fileupload">    
                              <div className="jd-fileuploader-one">  
                              <Form.Label style={{marginTop:'2px'}}>Enter the resume folder</Form.Label>                  
                                <Form.Control
                                  type="file"
                                  webkitdirectory="true"
                                  placeholder="Please enter the folder path"
                                  aria-describedby="inputPath"
                                  required
                                  name="jdfile"
                                  className="form-control"
                                  // ref={pathref}
                                  //value={folderpathnew}
                                  onChange={handleFileChange}
                                  />
                                  <Form.Control.Feedback type="invalid">
                                    Please Enter a Path
                                  </Form.Control.Feedback>
                                </div>
                         
                              <div className="jd-fileuploader-two">
                                <Form.Label style={{marginTop:'2px'}}>Enter the jd folder</Form.Label>
                                  <Form.Control
                                    type="file"
                                    webkitdirectory="true"
                                    placeholder="Please enter the folder path"
                                    aria-describedby="inputPath"
                                    required
                                    name="jdfiles"
                                    className="form-control"
                                    // ref={pathref}
                                    //value={folderpathnew}
                                    onChange={handleFileChange}
                                    />
                                    <Form.Control.Feedback type="invalid">
                                        Please Enter a Path
                                    </Form.Control.Feedback>                              
                                 
                                   
                                </div>
 
                                {/* <div className="jd-api-input-file-section" >  */}
                                  <Form.Label style={{marginTop:'5px'}}>Enter the Gemini API key <a className="text-decoration" href="
https://aistudio.google.com/app/apikey"
>(Click here to get your API key)</a></Form.Label>
                                    <input className="form-control input-text-height"
                                        required
                                        placeholder="Gemini API key"
                                        value={apikey}
                                        onChange={e => setAPIKey(e.target.value)}
                                    />
                                    {/* </div> */}
                              </div>
                        </InputGroup>
                      </Form.Group>
              </div>
              </div>

              <div className="submit-block"><button className="submit-button btn btn-primary" onClick={jdSubmit}>Submit</button></div>

              </Form>
              }
              


              </div>
              
              </div>
              
            <div className="right-content-block">
            <div className="right-image">
             <img src="https://cognizant.scene7.com/is/image/cognizant/digitally-transformed-contact-center-cuts-aht-by-twenty-five-percent?wid=600&fit=wrap" alt="right-img"/>
            </div>
            </div>
            {tablefield &&
          <Modal   size="lg" show={show} onHide={handleModalClose}>
            <Modal.Header closeButton>
              <Modal.Title>Summary</Modal.Title>
            </Modal.Header>
            <Modal.Body>
            <table className="resume-summary">
            <tbody>
            <tr>
                <th># Resume to Screen</th>
                <th>Primary Skills</th>
                <th>Additional Skills</th>
                {/*<th>Path to the Folder</th> */}
            </tr>
               {
              data && data.map((item,index) => (
              <tr key={index}>
               <td>{item.serial}</td>
               <td>{item.skillset}</td>
               <td>{item.additionalSkills}</td>
               {/*<td>{item.path}</td>*/}
               </tr>
                )
                )}
                </tbody>
            </table>
            <br></br>
            <small>Please verify details & click on generate to proceed ahead</small>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary btn-sm" onClick={handleModalClose}>
                Modify
              </Button>
              <Button variant="primary btn-sm" onClick={handleSubmit}>
              Generate
              </Button>
            </Modal.Footer>
          </Modal>   
            }
            {jdfield &&
          <Modal   size="lg" show={show} onHide={handleModalClose}>
            <Modal.Header closeButton>
              <Modal.Title>Job Description</Modal.Title>
            </Modal.Header>
            <Modal.Body>
            <table className="resume-summary">
            <tbody>
            <tr>
                <th># Resume to Screen</th>
                <th>Number of JD</th>
            </tr>
               {
              data && data.map((item,index) => (
              <tr key={index}>
               <td>{item.serial}</td>
               <td>{item.jdserial}</td>
               </tr>
                )
                )}
                </tbody>
            </table>
            
            {/* <label className= "form-label">Questions</label>
            <textarea className="form-control input-height" value={data && data[0].questions}/> */}

            {
              data && data[0].questions.map((item, index) => (
                <div key={index}>
                  <label className= "form-label" style={{fontSize:"13px", marginTop:"5px"}}>{item.filename}</label>
                  <textarea className="form-control input-height-jd-submit" value={item.questions.join('\n')}/>
                </div>
              ))
            }
            
            <br></br>
            <small>Please verify details & click on generate to proceed ahead</small>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary btn-sm" onClick={handleModalClose}>
                Modify
              </Button>
              <Button variant="primary btn-sm" onClick={handleSubmit3}>
              Generate
              </Button>
            </Modal.Footer>
          </Modal>   
            }   
            </div>{/* top container block */}

            <div className="full-width-block mid-container">
            <div className="full-content-block col-sm-12">
              <div className="about-block">
              <h5>About</h5>
              <p>iReS is Gen AI enabled platform. Your Ultimate Hiring Partner! Harness the power of artificial intelligence to identify the most relevant candidates, saving you time and resources in the hiring process. where we redifine traditional talent acquisition with cutting-edge artificial intelligence. </p> 
              <p>At Intelligent Resume Screening, we only work with experienced and friendly professionals to ensure that we provide the best possible service. Our team is dedicated to completing projects efficiently and on schedule, and we go above and beyond to form lasting relationships with our clients.</p>
              </div>
              <div className="about-block key-features">
              <h5>Technology</h5>
              <div className="tech-content">
              {
                buttonText.map((item,index)=>{
                  return <button key={index} type="button" className="btn btn-dark btn-sm rounded-pill">{item}</button>
                })
              }
              </div>
              </div>
              </div>
            </div>
            </div>
            {informationField &&
          <Modal size="lg" className="InformationModelWrapper" show={InfoModalshow} onHide={infoModelClose}>
            <Modal.Header closeButton>
              <Modal.Title>Information Overview</Modal.Title>
            </Modal.Header>
            <Modal.Body>
            <div className="InformationModelContent">
              <div>
                <strong>Primary Skills: </strong> Recruiter should select a value from dropdown. Based on selected categories resumes will be filtered.
              </div>
              <hr></hr>
              <div>
                <strong>Additional Skills: </strong> Along with Primary skills if a Recruiter is looking for additinal skills then this feature can be utlized. e.g. Candidate with Data Science + Power BI experience
              </div>
              <hr></hr>
              <div>
                <strong>Path: </strong> Path of Local Repository where all Resumes are stored.
              </div>
            </div>
            </Modal.Body>
            <Modal.Footer>
              <Button variant="secondary btn-sm" onClick={infoModelClose}>
                Close
              </Button>
            </Modal.Footer>
          </Modal>   
            } 
        </div>

        
    )
}
export default Resumescreening;
