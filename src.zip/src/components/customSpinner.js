import React from 'react';
import Spinner from 'react-bootstrap/Spinner';
 
function CustomSpinner({ progress }) {
    const roundedProgress = Math.round(progress);
    return (
        <div className="custom-spinner">
            <div className="fade modal-backdrop show"></div>
            <Spinner animation="border" role="status">
                <span className="visually-hidden">Loading...</span>
            </Spinner>
            <div className='percentage-display'>{roundedProgress}%</div>
        </div>
    );
}
 
export default CustomSpinner;