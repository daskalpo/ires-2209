import React from 'react';
import axios from 'axios';
import Button from 'react-bootstrap/Button';
function FolderUploader({ onUpload, onError }) {
 const handleFolderUpload = async (event) => {
   const files = event.target.files;
   const formData = new FormData();
   
   let folderPath = '';
   
   if (files.length > 0) {
      // Extract the folder path from the first file's webkitRelativePath
      const firstFileRelativePath = files[0].webkitRelativePath; 
      folderPath = firstFileRelativePath.substring(0, firstFileRelativePath.lastIndexOf('/'));  
      console.log('Local Folder Path:', folderPath); // Log the local folder path
      formData.append('folderPath', folderPath); // Add folder path to form data
    }
   
   // Add each file in the folder to formData
   for (let i = 0; i < files.length; i++) {
     formData.append('files', files[i], files[i].webkitRelativePath);
   }
   try {
     const response = await axios.post('http://54.237.10.33:3001/backend/upload', formData, {
       headers: {
         'Content-Type': 'multipart/form-data',
       },
     });
     onUpload(response.data); // Handle successful upload
   } catch (error) {
     onError(error); // Handle upload error
   }
 };
 return (
<div>
<input
       type="file"
       webkitdirectory="true" // Allows folder upload
       directory=""
       multiple
       onChange={handleFolderUpload}
       style={{ display: 'none' }}
       id="folder-input"
     />
<label htmlFor="folder-input">
<Button variant="primary" as="span">Upload Folder</Button>
</label>
</div>
 );
}
export default FolderUploader;