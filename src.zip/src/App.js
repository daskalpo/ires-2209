// import Talentscan from './components/talentscan';
import { BrowserRouter as Router, Routes, Route,Link, useHistory} from "react-router-dom";
import Summary from './components/summary';
import Resumescreening from './components/resumescreening';
import Datatable from './components/datatable';
import Jobdescription from "./components/jobdescription";
import './App.css';
import './summary.css';

function App() {
  return (
    <div className="App">
      <div id="wrapper">
      <Router>
        <header>
        <div className="row1">
        <h4 className="title-logo"><a href="http://localhost:3000/"><img src="images/irslogo.png" alt=""/>iReS </a></h4>
        <div className="abbreivenew-text">Intelligent Resume Screening <small>Powered by Gen AI</small></div>
        {/* <div className="home-button"><Link to="/summary" className="btn btn-primary">Home</Link></div> */}
        </div>
        </header>
        <div className="wrapper-container">
        <div className="row1">
        
        {/* <Link to="/home">Home</Link>
        <Link to="/about">About</Link> */}
        <Routes>
            <Route exact path="/" element={<Resumescreening/>}></Route>
            <Route exact path="/summary" element={<Summary />}></Route>
            <Route exact path="/datatable" element={<Datatable/>}></Route>
            <Route exact path="/jobdescription" element={<Jobdescription/>}></Route>
        </Routes>
        
         {/* <Talentscan/> */}
       </div>
       </div>
       </Router>
       <footer>
       <div className="row1">
         <div className="inquire-block"><img src="images/Picture1.png" alt="logo"/> 
         <span className="reserved-text">@2024 Cognizant. All Rights Reserved</span>
         </div>
         <div className="inquiries-content">
           <span> For any inquiries, please reach out to us at <a href="mailto:Payal-1.Mangal-1@cognizant.com" className="link">Payal-1.Mangal-1@cognizant.com</a></span>
           </div>
         <div className="rights-block">
           {/* <ul>
           <li><a href="http://www.linkedin.com/company/cognizant" target={'_blank'}><i className="bi bi-linkedin"></i>
            </a>
            </li>
           <li><a href="http://twitter.com/cognizant" target={'_blank'}>
            <i className="bi bi-twitter-x"></i>
            </a></li>
            <li><a href="http://www.facebook.com/Cognizant" target={'_blank'}>
            <i className="bi bi-facebook"></i>
            </a></li>
            <li><a href="https://www.instagram.com/cognizant/" target={'_blank'}>
            <i className="bi bi-instagram"></i>
            </a></li>
            <li><a href="https://www.youtube.com/cognizant" target={'_blank'}>
           <i className="bi bi-youtube"></i>
            </a></li>
            <li>
               <a href="http://www.cognizant.com/Pages/rss.aspx" target={'_blank'}><i className="bi bi-rss-fill"></i></a>
             </li>
           </ul> */}
           
         </div>
         </div>
       </footer>
      </div>
    </div>
  );
}

export default App;
